:::warning 注意 :
以下所有模板为单独项目和 `GoView` 没有关联性
:::

* React 模板1

地址：[https://gitee.com/MTrun/react-big-screen](https://gitee.com/MTrun/react-big-screen)

![react-screen-1](./images/react-screen-1.png)