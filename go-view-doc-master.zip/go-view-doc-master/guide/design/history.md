注意:当前操作类型有限，并不是所有操作都会记录，并且一次操作包含多次类型过程无法处理，后期将会更改
、<img src="./images/history.png" alt="历史纪录" style="zoom:100%; border-radius: 20px" />
