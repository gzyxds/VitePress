## 初始页面

<img src="./images/pageGuide2.png" alt="初始页面" style="zoom:130%; border-radius: 10px" />

## 编辑区域

功能区展示方式可在【右上角头像 -> 下拉菜单 -> 全局设置-> 工具栏展示进行设置】

<img src="./images/pageGuide1.png" alt="编辑区域" style="zoom:130%; border-radius: 10px" />

## 编写数据过滤函数

<img src="./images/pageGuide3.png" alt="过滤函数" style="zoom:130%; border-radius: 10px" />
<img src="./images/pageGuide4.png" alt="过滤函数" style="zoom:130%; border-radius: 10px" />

## 快捷键列表
<img src="./images/pageKeyList.png" alt="快捷键列表" style="zoom:130%; border-radius: 10px" />