:::warning 注意 :
以下所有模板为单独项目和 `GoView` 没有关联性
:::


* Vue 模板1

Vue2地址：[https://gitee.com/MTrun/big-screen-vue-datav](https://gitee.com/MTrun/big-screen-vue-datav)

Vue3地址：[https://gitee.com/MTrun/vue-big-screen-plugin](https://gitee.com/MTrun/vue-big-screen-plugin)

![vue-screen-1](./images/vue-screen1.png)

* Vue 模板2

Vue2地址：[https://gitee.com/daidaibg/IofTV-Screen](https://gitee.com/daidaibg/IofTV-Screen)

Vue3地址：[https://gitee.com/daidaibg/IofTV-Screen-Vue3](https://gitee.com/daidaibg/IofTV-Screen-Vue3)

![vue-screen-2](./images/vue-screen2.png)
