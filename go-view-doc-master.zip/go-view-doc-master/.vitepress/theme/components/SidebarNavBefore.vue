<template>
  <div>
    <p align="center">
      <a
        href="https://ai.goviewlink.com/saas/"
        target="_blank"
        style="display: inline-block"
      >
        <img
          src="/GoViewPro_mini.png"
          alt="go-view"
          style="border-radius: 10px"
        />
      </a>
    </p>
  </div>
</template>
