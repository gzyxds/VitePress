
注意：切换语言刷新页面，不会保存当前页面数据，请谨慎勾选

<img src="./images/setting.png" alt="全局设置" style="width: 980px; zoom:50%; border-radius: 20px" />

选择侧边栏模式

<div style="display: flex; flex-wrap: wrap; gap: 10px">
  <img src="./images/settingAside.png" alt="全局设置" style="width: 980px; zoom:50%; border-radius: 20px" />
  <img src="./images/settingAsideRes.png" alt="全局设置" style="height: 450px; zoom:50%; border-radius: 20px" />
</div>

选择Dock模式

<div style="display: flex; flex-wrap: wrap; gap: 10px">
  <img src="./images/settingDock.png" alt="全局设置" style="width: 980px; zoom:50%; border-radius: 20px" />
  <img src="./images/settingDock.Res.png" alt="全局设置" style="height: 450px; zoom:50%; border-radius: 20px" />
</div>


全局颜色设置

<img src="./images/color.png" alt="全局颜色" style="zoom:130%; border-radius: 10px" />

全局主题设置

<img src="./images/theme.png" alt="全局颜色" style="zoom:130%; border-radius: 10px" />