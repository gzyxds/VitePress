<template>
  <div class="layout-bottom">
    本文档内容版权属于 GoView 作者，保留所有权利
    <span>|</span>
    备案号
    <a href="https://beian.miit.gov.cn/" target="_blank">京ICP备2021034585号-1</a>
  </div>
</template>


<style lang="scss" scoped>
.layout-bottom {
  padding: 20px 0 20px;
  text-align: center;
  line-height: 24px;
  font-size: 14px;
  font-weight: 500;
  color: var(--vp-c-text-2);
  border-top: 1px solid var(--vp-c-divider-light);
  span {
    padding: 0 20px;
  }
  a {
    color: var(--vp-button-brand-bg);
    ;
  }
}
</style>