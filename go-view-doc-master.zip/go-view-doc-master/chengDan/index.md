<div>
  <img src="./images/chengDan_logo.png" style="height: 50px">
</div>

:::tip 使用推荐方式，享受 9 折优惠，加 QQ: 1262327911
添加 QQ 或与橙单人员标注推荐人为 GoView 作者【奔跑的面条】，购买橙单任意服务既可打 **9** 折！！
:::

<div id="cheng-dan">
  <p class="cheng-dan_title">强大的代码生成</p>
  <p class="font-size14 subtilte mb-0">可生成「产品级」的前后端代码（点击图片查看详情）</p>
  <a href="https://www.orangeforms.com?from=goview" style="display: block" target="_blank">
    <img class="cheng-dan_bg" src="./images/chengDan_index.png" />
  </a>

  <p class="cheng-dan_title">完善的功能模块</p>
  <p class="font-size14 subtilte mb-0">全部自主研发，功能「完整可控」（点击图片查看详情）</p>
  <a href="https://www.orangeforms.com?from=goview" style="display: block" target="_blank">
  <img src="./images/flow.png">
  </a>
  <br />
  <p class="cheng-dan_title">建议推荐方式, 享9折优惠，加 QQ 好友进行私聊：</p>
  <div class="cheng-dan_center">
    <img src='./images/qq-person.png' style="position:relative; top: 10px; margin-left: 20px; height: 350px;">
  </div>
</div>

<style scoped>
  #cheng-dan {
    margin-top: 50px;
    text-align: center;
  }
  #cheng-dan .cheng-dan_title{
    font-weight: 600;
    font-size: 24px;
  }
  #cheng-dan .cheng-dan_bg {
    width: 100%;
  }
  #cheng-dan .cheng-dan_center {
    display: flex;
    justify-content: center;
  }
</style>
